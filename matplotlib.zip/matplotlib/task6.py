import numpy as np
import matplotlib.pyplot as plt
#filling a data 
xrange = np.arange(-3, 3, 0.1)
yrange = np.arange(-3, 3, 0.1)
X, Y = np.meshgrid(xrange,yrange)
# F is one side of the equation, G is the other F-G=0
F = (X**2+Y**2)**2
G = 7*(X**2-Y**2)
plt.contour((F - G), [0])
plt.show()