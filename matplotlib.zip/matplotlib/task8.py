import matplotlib
from matplotlib import pyplot as plt, patches
#radius
a=5
my_dpi=400
#plot definitions
fig = plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
ax = fig.add_subplot(111)
#add rectangle and circle
rect = patches.Rectangle((-a, -a), 2*a, 2*a, color='black')
circle = patches.Circle((0, 0), radius=a, color='green')
ax.add_patch(rect)
ax.add_patch(circle)
#axes limits
plt.xlim([-1*a, a])
plt.ylim([-1*a, a])
#fix axes scale
plt.axis('equal')
#plot
plt.show()
#save
fig.savefig('my_fig.png',dpi=my_dpi)