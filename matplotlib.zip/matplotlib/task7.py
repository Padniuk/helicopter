import sys
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
#definition of function
def f(arg):
    x = arg[0]
    y = arg[1]
    return np.sin(x-2*y)*np.exp(-np.absolute(y))
#filling a data 
x = np.arange(0, np.pi, 0.1)
y = np.arange(-1, 1, 0.1)
x, y = np.meshgrid(x, y)
#mode 1 wireframe and surface
if sys.argv[1] == "1":
    z = np.array([f(arg) for arg in zip(x,y)])
    #wireframe
    fig = plt.figure()
    ax = fig.add_subplot(1, 2, 1, projection='3d')
    ax.plot_wireframe(x, y, z)
    #surface
    ax = fig.add_subplot(1, 2, 2, projection='3d')
    ax.plot_surface(x, y, z)

    plt.show()
#mode 2 different view
elif sys.argv[1] == "2":
    z = np.array([f(arg) for arg in zip(x,y)])
    fig = plt.figure()
    
    ax = fig.add_subplot(1, 3, 1, projection='3d')
    ax.plot_surface(x, y, z)

    ax.elev = 0
    ax.azim = 270  # xz view
    
    ax = fig.add_subplot(1, 3, 2, projection='3d')
    ax.plot_surface(x, y, z)


    ax.elev = 0
    ax.azim = 0    # yz view

    ax = fig.add_subplot(1, 3, 3, projection='3d')
    ax.plot_surface(x, y, z)

    ax.elev = 0
    ax.azim = -90  # xy view

    plt.show()

