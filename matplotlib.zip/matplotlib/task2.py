import numpy as np
import matplotlib.pyplot as plt

#filling a data 
phi = np.arange(0, 2*np.pi, 0.01)
rho = np.array([1-np.sin(i) for i in phi])

fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})#definition of polar plot
ax.plot(phi, rho,color='orange',marker='^',linewidth=3)#color-marker-linewidth setting
ax.set_title("A line plot on a polar axis")#title
ax.set_rticks([0.7, 1.4]) # rho ticks
plt.show()#plot
