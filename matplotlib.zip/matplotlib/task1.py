import sys
import numpy as np
import matplotlib.pyplot as plt

#filling a data 
x1 = np.arange(-1, 1, 0.1)
x2 = np.arange(0, 1, 0.1) 

f = np.array([x**3+2*x**2+1 for x in x1])
g = np.array([(x-1)**4 for x in x1])
u = np.array([np.sqrt(x) for x in x2])
v = np.array([np.exp(-1*x**2) for x in x2])

#mode 1 plot for all graphs
if sys.argv[1] == "1":
    plt.title('General plot')# title
    fig, = plt.plot(x1,f,color='r',label='f(x)', marker='o', linestyle='dashed', linewidth=0.5, markersize=2)# data, color label, marker style etc...
    fig, = plt.plot(x1,g,color='b',label='g(x)', marker='*', linewidth=0.5, markersize=4)# data, color label, marker style etc...
    fig, = plt.plot(x2,u,color='g',label='u(x)',marker='1')# data, color label, marker style etc...
    fig, = plt.plot(x2,v,color='k',label='v(x)', linestyle=':', linewidth=2)# data, color label, marker style etc...
    #grid and legend
    plt.grid(True, which='both')
    plt.legend()
    #labels for axes
    plt.xlabel("X")
    plt.ylabel("Y")
    #plot
    plt.show()

#mode 2 separated plots
elif sys.argv[1] == "2":
    fig, ax = plt.subplots(nrows=2, ncols=2)#definition of subplots
    fig.suptitle('Separated plots')#general title
    ax[0, 0].plot(x1,f,color='r',label='f(x)', marker='o', linestyle='dashed', linewidth=0.5, markersize=2) #row=0, col=0
    ax[1, 0].plot(x1,g,color='b',label='g(x)', marker='*', linewidth=0.5, markersize=4) #row=1, col=0
    ax[0, 1].plot(x2,u,color='g',label='u(x)',marker='1') #row=0, col=1
    ax[1, 1].plot(x2,v,color='k',label='v(x)', linestyle=':', linewidth=2) #row=1, col=1
    
    ax[0, 0].title.set_text('1')#title for  0  0 subplot
    ax[1, 0].title.set_text('2')#title for  1  0 subplot
    ax[0, 1].title.set_text('3')#title for  0  1 subplot
    ax[1, 1].title.set_text('4')#title for  1  1 subplot
    #grid for all subplots
    ax[0, 0].grid(True, which='both')
    ax[1, 0].grid(True, which='both')
    ax[0, 1].grid(True, which='both')
    ax[1, 1].grid(True, which='both')
    #legend for all subplots
    ax[0, 0].legend()
    ax[1, 0].legend()
    ax[0, 1].legend()
    ax[1, 1].legend()
    #plot
    plt.show()
    