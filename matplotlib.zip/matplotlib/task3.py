import numpy as np
import matplotlib.pyplot as plt

#definition of function
def f(x):
    if x <= np.e and x >= 1:
        return np.log(x)
    elif x <= 9 and x > np.e:
        return x/np.e
    elif x <= 12 and x > 9:
        return 9*np.exp(8-x)

#filling a data 
x1 = np.arange(1, np.e, 0.1)
x2 = np.arange(np.e, 9, 0.1)
x3 = np.arange(9, 12, 0.1)
y1 = np.array([f(i) for i in x1])
y2 = np.array([f(i) for i in x2])
y3 = np.array([f(i) for i in x3])
#different colors and style
fig, = plt.plot(x1,y1,color='r', linestyle='--')
fig, = plt.plot(x2,y2,color='g', linestyle='-')
fig, = plt.plot(x3,y3,color='b', linestyle='-.')
plt.show()#plot