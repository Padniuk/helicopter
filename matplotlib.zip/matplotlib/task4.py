import numpy as np
import matplotlib.pyplot as plt

#filling a data 
t = np.arange(0, 2*np.pi, 0.01)
x = np.array([9*np.sin(i/10)-0.5*np.sin(9*i/10) for i in t])
y = np.array([9*np.cos(i/10)+0.5*np.cos(9*i/10) for i in t])  
#plot
fig, = plt.plot(x,y)
plt.show()