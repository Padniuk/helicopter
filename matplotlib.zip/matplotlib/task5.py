import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import LineString
#filling a data 
x = np.arange(0, 10, 0.01)
y1 = np.array([6*i-2 for i in x])
y2 = np.array([-1*i+12 for i in x])

plt.plot(x, y1, '-')
plt.plot(x, y2, '-')

plt.text(0.5*(x.max()-x.min()), 0.5*(y1.max()-y1.min())+4.5, 'y=6x-2')
plt.text(0.5*(x.max()-x.min()), 0.5*(y2.max()-y2.min())+2.5, 'y=-x+12')

#searching of intersection ingeneral
first_line = LineString(np.column_stack((x, y1)))
second_line = LineString(np.column_stack((x, y2)))
intersection = first_line.intersection(second_line)

#ploting
if intersection.geom_type == 'MultiPoint':
    plt.plot(*LineString(intersection).xy, 'o')
    for i, j in list(*LineString(intersection).xy):
        plt.text(i-0.7, j+2, '({}, {})'.format(i, j))
elif intersection.geom_type == 'Point':
    plt.plot(*intersection.xy, 'o')
    plt.text(intersection.x-0.7, intersection.y+2, '({}, {})'.format(intersection.x, intersection.y))

plt.show() 
